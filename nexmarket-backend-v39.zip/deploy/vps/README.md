# Déploiement sur un serveur dédié (Hetzner, Contabo, Vultr…)

À utiliser si MoneyFusion refuse les IP partagées de Render : vous avez **une seule IP à vous**.

1. **Serveur** : Ubuntu 24.04, 1 à 2 Go de RAM, avec une IPv4 publique. Notez l'IP.
2. **Domaine** : créez un enregistrement DNS `A` (ex. `api.votredomaine.com`) vers cette IP.
   Sans domaine, un sous-domaine gratuit (ex. DuckDNS) convient : le HTTPS est obligatoire.
3. **Docker** : `curl -fsSL https://get.docker.com | sh`
4. **Pare-feu** : `ufw allow 22 && ufw allow 80 && ufw allow 443 && ufw enable`
5. **Code** : copiez le dossier backend sur le serveur (git clone ou scp), puis :
   `cd deploy/vps && cp .env.example .env && nano .env`
6. **Lancer** : `docker compose up -d --build` puis `docker compose logs -f api`
   (cherchez `[nexmarket] conteneur lance`, aucune variable « ABSENTE »).
7. **IP à déclarer chez MoneyFusion** : `docker compose exec api python -c "import httpx;print(httpx.get('https://api.ipify.org').text)"`
   doit afficher l'IPv4 du serveur (sinon, IPv6 : vérifiez le `sysctls` du compose). Enregistrez-la.
8. **Frontend** : dites-lui la nouvelle adresse. Dans `index.html`, avant `app.js` :
   `<script>window.NEXMARKET_API_URL="https://api.votredomaine.com/api"</script>`
   et mettez ce domaine dans `CORS_ORIGINS` / `PUBLIC_URL`.
9. **Reprise des données depuis Render** (si déjà en service) : `pg_dump` de l'ancienne base,
   puis `docker compose exec -T db psql -U nexmarket nexmarket < sauvegarde.sql`.
   Arrêtez l'ancien service avant, pour qu'un seul bot Telegram tourne (sinon erreur 409).
10. **Sauvegardes** : planifiez un `pg_dump` régulier (la base est sur le disque du serveur).
