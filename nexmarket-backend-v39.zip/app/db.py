import logging
from collections.abc import AsyncGenerator
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.config import settings


def normalize_database_url(url: str) -> tuple[str, dict]:
    """
    Convertit une URL PostgreSQL classique vers asyncpg.

    - postgres:// et postgresql:// -> postgresql+asyncpg://
    - asyncpg REFUSE le paramètre `?sslmode=...` (TypeError au premier
      accès à la base) : il est retiré et converti en option SSL.
    """

    url = (url or "").strip()

    for prefix in (
        "postgresql+psycopg://",
        "postgresql://",
        "postgres://",
    ):
        if url.startswith(prefix):
            url = "postgresql+asyncpg://" + url[len(prefix):]
            break

    connect_args: dict = {}

    parts = urlsplit(url)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))

    sslmode = query.pop("sslmode", None)

    if sslmode and sslmode != "disable":
        connect_args["ssl"] = "require"

    if sslmode is not None:
        url = urlunsplit(
            parts._replace(query=urlencode(query))
        )

    return url, connect_args


DATABASE_URL, _CONNECT_ARGS = normalize_database_url(
    settings.DATABASE_URL
)

# =========================================================
# SQLALCHEMY ENGINE
# =========================================================

engine = create_async_engine(
    DATABASE_URL,
    # Délais courts : une base injoignable doit échouer vite, pas bloquer
    # l'application 60 s (valeur par défaut d'asyncpg).
    connect_args={
        **_CONNECT_ARGS,
        "timeout": 10,
        "command_timeout": 30,
    },
    echo=False,
    pool_pre_ping=True,
    pool_recycle=1800,
    pool_size=10,
    max_overflow=10,
    pool_timeout=15,
)


# =========================================================
# SESSION FACTORY
# =========================================================

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


# =========================================================
# BASE MODEL
# =========================================================

class Base(DeclarativeBase):
    pass


# =========================================================
# DATABASE DEPENDENCY
# =========================================================

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Fournit une session PostgreSQL à chaque requête.

    En cas d'erreur, la transaction est annulée.
    """

    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


# =========================================================
# INITIALISATION
# =========================================================

async def init_db() -> None:
    """
    Initialise les tables connues par SQLAlchemy.

    Les imports ci-dessous sont volontairement effectués
    avant create_all afin d'enregistrer les modèles.
    """

    from app.models import channel
    from app.models import favorite
    from app.models import listing
    from app.models import message
    from app.models import platform
    from app.models import report
    from app.models import review
    from app.models import transaction
    from app.models import user
    from app.models import wallet

    _ = (
        channel,
        favorite,
        listing,
        message,
        platform,
        report,
        review,
        transaction,
        user,
        wallet,
    )

    async with engine.begin() as connection:
        await connection.run_sync(
            Base.metadata.create_all
        )

    await apply_schema_patches()


# create_all() ne MODIFIE jamais une table existante. Ces correctifs,
# idempotents, ajoutent les colonnes introduites après la création de la
# base (aucun SQL à lancer à la main).
SCHEMA_PATCHES = [
    "ALTER TABLE deposits ADD COLUMN IF NOT EXISTS country VARCHAR(10)",
    # Paiement en GRAM (v20)
    "ALTER TABLE listings ADD COLUMN IF NOT EXISTS seller_gram_address VARCHAR(80)",
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS buyer_gram_address VARCHAR(80)",
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS seller_gram_address VARCHAR(80)",
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS gram_tx_hash VARCHAR(120)",
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS gram_release_tx_hash VARCHAR(120)",
    "CREATE INDEX IF NOT EXISTS ix_transactions_gram_tx_hash ON transactions (gram_tx_hash)",
    # Aperçus visibles par les acheteurs (v21)
    "ALTER TABLE listing_proofs ADD COLUMN IF NOT EXISTS kind VARCHAR(12) NOT NULL DEFAULT 'proof'",
    # Retraits MoneyFusion (v28) : pays / réseau / numéro / montant local
    "ALTER TABLE withdrawals ALTER COLUMN jessikapay_jp_number DROP NOT NULL",
    "ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS payout_country VARCHAR(10)",
    "ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS payout_method VARCHAR(60)",
    "ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS payout_phone VARCHAR(40)",
    "ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS payout_currency VARCHAR(10)",
    "ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS payout_amount NUMERIC(18,2)",
    # Inscription en 3 étapes (v29)
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS country VARCHAR(2)",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(20)",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarded_at TIMESTAMPTZ",
    # Achat direct + versement automatique au vendeur (v30)
    "ALTER TABLE deposits ADD COLUMN IF NOT EXISTS purpose VARCHAR(20) NOT NULL DEFAULT 'deposit'",
    "ALTER TABLE deposits ADD COLUMN IF NOT EXISTS listing_id INTEGER",
    "ALTER TABLE listings ADD COLUMN IF NOT EXISTS payout_country VARCHAR(10)",
    "ALTER TABLE listings ADD COLUMN IF NOT EXISTS payout_method VARCHAR(60)",
    "ALTER TABLE listings ADD COLUMN IF NOT EXISTS payout_phone VARCHAR(40)",
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS seller_payout_started_at TIMESTAMPTZ",
]


async def apply_schema_patches() -> None:
    from sqlalchemy import text

    for statement in SCHEMA_PATCHES:
        try:
            async with engine.begin() as connection:
                await connection.execute(text(statement))
        except Exception as exc:  # une base sans la table : ignoré
            logging.getLogger("nexmarket.db").warning(
                "Correctif de schéma ignoré (%s) : %s", statement, exc
            )


# =========================================================
# FERMETURE
# =========================================================

async def close_db() -> None:
    """
    Ferme proprement le pool de connexions.
    """

    await engine.dispose()
