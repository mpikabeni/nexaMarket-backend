import asyncio
from datetime import datetime, timezone
import hmac
import time

from fastapi import (
    Response,
    APIRouter,
    Header,
    HTTPException,
    Request,
    status,
)
from pydantic import BaseModel
from sqlalchemy import func, or_, select

from app.auth import (
    create_access_token,
    validate_telegram_init_data,
)
from app.config import settings
from app.deps import CurrentAdmin, DBSession
from app.models.channel import Channel
from app.models.listing import Listing
from app.services import gram_service, money_notifications
from app.services.notification_service import (
    notify_user_id,
    schedule_new_listing_broadcast,
)
from app.models.message import Message
from app.models.platform import PlatformWallet
from app.models.listing_proof import ListingProof
from app.models.schemas import (
    AnnouncementRequest,
    RejectRequest,
    WithdrawalResolveRequest,
)
from app.services.telegram_service import get_telegram_service
from app.models.withdrawal import Withdrawal
from app.models.deposit import Deposit
from app.services.deposit_sync import credit_deposit_manually, sync_deposit
from app.services.jessikapay import jessikapay_service
from app.services.moneyfusion import MoneyFusionError
from app.services.payout_sync import sync_withdrawal
from app.models.platform import CommissionPayout
from app.services.payout_settlement import complete_withdrawal, fail_withdrawal
from app.models.report import Report
from app.models.transaction import Transaction
from app.models.user import User
from app.models.wallet import Wallet


router = APIRouter(
    prefix="/admin",
    tags=["Admin"],
)


# ============================================================
# ADMIN LOGIN
# ============================================================

class AdminLoginRequest(BaseModel):
    code: str


# Limite d'essais : 5 échecs / 10 min par adresse IP (mémoire du processus ;
# le service tourne avec un seul worker). Évite de deviner le code admin.
_LOGIN_MAX_FAILURES = 5
_LOGIN_WINDOW_SECONDS = 600
_login_failures: dict[str, list[float]] = {}


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "inconnu"


def _login_check(ip: str) -> None:
    now = time.monotonic()
    recent = [
        t for t in _login_failures.get(ip, [])
        if now - t < _LOGIN_WINDOW_SECONDS
    ]
    if recent:
        _login_failures[ip] = recent
    else:
        _login_failures.pop(ip, None)

    if len(recent) >= _LOGIN_MAX_FAILURES:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Trop de tentatives. Réessaie dans quelques minutes.",
        )


def _login_failed(ip: str) -> None:
    _login_failures.setdefault(ip, []).append(time.monotonic())
    if len(_login_failures) > 1000:
        _login_failures.clear()


@router.post("/login")
async def admin_login(
    payload: AdminLoginRequest,
    request: Request,
    db: DBSession,
    telegram_init_data: str | None = Header(
        default=None,
        alias="X-Telegram-Init-Data",
    ),
):
    """
    Connexion administrateur NexMarket.

    Le frontend envoie :
        {
            "code": "CODE_ADMIN"
        }

    ainsi que le header :
        X-Telegram-Init-Data

    Le compte Telegram doit correspondre à
    ADMIN_TELEGRAM_ID dans Render.
    """

    # --------------------------------------------------------
    # Vérification de la configuration
    # --------------------------------------------------------

    if not settings.ADMIN_CODE:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Le code administrateur n'est pas configuré "
                "(variable ADMIN_CODE sur Render)."
            ),
        )

    # --------------------------------------------------------
    # Vérification du code administrateur
    # --------------------------------------------------------

    ip = _client_ip(request)
    _login_check(ip)

    if not payload.code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Le code administrateur est obligatoire.",
        )

    if not hmac.compare_digest(
        str(payload.code),
        str(settings.ADMIN_CODE),
    ):
        _login_failed(ip)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Code administrateur incorrect.",
        )

    # --------------------------------------------------------
    # Vérification Telegram
    # --------------------------------------------------------

    if not telegram_init_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Les données Telegram sont absentes. "
                "Ouvrez l'administration depuis la Mini App."
            ),
        )

    try:
        telegram_data = validate_telegram_init_data(
            telegram_init_data
        )

    except HTTPException:
        raise

    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Les données Telegram sont invalides "
                "ou expirées."
            ),
        )

    # --------------------------------------------------------
    # Récupération Telegram ID
    # --------------------------------------------------------

    try:
        telegram_id = int(
            telegram_data["telegram_id"]
        )

    except (
        KeyError,
        TypeError,
        ValueError,
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Impossible de récupérer "
                "l'identifiant Telegram."
            ),
        )

    # --------------------------------------------------------
    # Recherche du compte utilisateur
    # --------------------------------------------------------

    result = await db.execute(
        select(User).where(
            User.telegram_id == telegram_id
        )
    )

    user = result.scalar_one_or_none()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Votre compte NexMarket est introuvable. "
                "Utilisez d'abord /start sur le bot."
            ),
        )

    # --------------------------------------------------------
    # Est-ce bien un administrateur ?
    # --------------------------------------------------------
    # MÊME règle que le bot (is_admin_user) : l'ID Telegram défini dans
    # ADMIN_TELEGRAM_ID, OU un compte déjà marqué administrateur.
    # Avant, la Mini App n'acceptait que ADMIN_TELEGRAM_ID : le bot te
    # reconnaissait admin mais la Mini App répondait « Accès refusé ».
    configured_admin = bool(settings.ADMIN_TELEGRAM_ID) and (
        telegram_id == int(settings.ADMIN_TELEGRAM_ID)
    )

    if not (configured_admin or user.is_admin):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Ce compte Telegram n'est pas administrateur de NexMarket."
                + (
                    ""
                    if settings.ADMIN_TELEGRAM_ID
                    else " Aucun ADMIN_TELEGRAM_ID n'est configuré "
                    "sur le serveur."
                )
            ),
        )

    # --------------------------------------------------------
    # Vérification compte actif
    # --------------------------------------------------------

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Votre compte NexMarket est désactivé.",
        )

    # --------------------------------------------------------
    # Promotion automatique en administrateur
    # --------------------------------------------------------

    if not user.is_admin:
        user.is_admin = True

        await db.commit()
        await db.refresh(user)

    # --------------------------------------------------------
    # Création du JWT
    # --------------------------------------------------------

    access_token = create_access_token(
        user.id
    )

    # --------------------------------------------------------
    # Réponse frontend
    # --------------------------------------------------------

    return {
        "token": access_token,
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in_minutes": (
            settings.JWT_EXPIRE_MINUTES
        ),
        "admin": {
            "id": user.id,
            "telegram_id": user.telegram_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "nexa_id": user.nexa_id,
            "is_admin": user.is_admin,
        },
    }


# ============================================================
# DASHBOARD
# ============================================================

@router.get("/dashboard")
async def admin_dashboard(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Statistiques générales de NexMarket.
    """

    users_count = await db.scalar(
        select(func.count(User.id))
    )

    channels_count = await db.scalar(
        select(func.count(Channel.id))
    )

    pending_channels = await db.scalar(
        select(func.count(Channel.id)).where(
            Channel.verification_status.in_(
                [
                    "pending",
                    "submitted",
                ]
            )
        )
    )

    listings_count = await db.scalar(
        select(func.count(Listing.id))
    )

    pending_listings = await db.scalar(
        select(func.count(Listing.id)).where(
            Listing.status == "pending_review"
        )
    )

    transactions_count = await db.scalar(
        select(func.count(Transaction.id))
    )

    active_transactions = await db.scalar(
        select(func.count(Transaction.id)).where(
            Transaction.status.in_(
                [
                    "pending_payment",
                    "waiting_admin",
                    "transfer_started",
                    "protection_period",
                    "disputed",
                ]
            )
        )
    )

    pending_reports = await db.scalar(
        select(func.count(Report.id)).where(
            Report.status.in_(
                [
                    "pending",
                    "investigating",
                ]
            )
        )
    )

    platform_balance = await db.scalar(
        select(func.coalesce(func.sum(PlatformWallet.available_balance), 0))
    )

    return {
        "platform_wallet": {
            "balance": platform_balance or 0,
            "currency": "XAF",
        },
        "users": users_count or 0,
        "channels": channels_count or 0,
        "pending_channels": pending_channels or 0,
        "listings": listings_count or 0,
        "pending_listings": pending_listings or 0,
        "transactions": transactions_count or 0,
        "active_transactions": active_transactions or 0,
        "pending_reports": pending_reports or 0,
    }


# ============================================================
# USERS
# ============================================================

@router.get("/users")
async def admin_users(
    current_admin: CurrentAdmin,
    db: DBSession,
    active_only: bool = False,
):
    """
    Liste les utilisateurs pour l'administration.
    """

    query = select(User).order_by(
        User.created_at.desc()
    )

    if active_only:
        query = query.where(
            User.is_active.is_(True)
        )

    result = await db.execute(query)

    users = result.scalars().all()

    return {
        "users": [
            {
                "id": user.id,
                "telegram_id": user.telegram_id,
                "nexa_id": user.nexa_id,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "is_active": user.is_active,
                "is_admin": user.is_admin,
                "language": user.language,
                "preferred_currency": (
                    user.preferred_currency
                ),
                "created_at": user.created_at,
                "updated_at": user.updated_at,
            }
            for user in users
        ],
        "count": len(users),
    }


# ============================================================
# ACTIVATE / DEACTIVATE USER
# ============================================================

@router.patch("/users/{user_id}/status")
async def change_user_status(
    user_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
    active: bool,
):
    """
    Active ou désactive un compte utilisateur.
    """

    result = await db.execute(
        select(User).where(
            User.id == user_id
        )
    )

    user = result.scalar_one_or_none()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Utilisateur introuvable.",
        )

    if user.id == current_admin.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Un administrateur ne peut pas "
                "désactiver son propre compte."
            ),
        )

    user.is_active = active

    await db.commit()
    await db.refresh(user)

    return {
        "status": "success",
        "user_id": user.id,
        "is_active": user.is_active,
    }


# ============================================================
# CHANNELS - PENDING
# ============================================================

@router.get("/channels/pending")
async def pending_channels(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Liste les chaînes nécessitant une vérification.
    """

    result = await db.execute(
        select(Channel)
        .where(
            Channel.verification_status.in_(
                [
                    "pending",
                    "submitted",
                ]
            )
        )
        .order_by(
            Channel.created_at.asc()
        )
    )

    channels = result.scalars().all()

    return {
        "channels": [
            {
                "id": channel.id,
                "telegram_username": (
                    channel.telegram_username
                ),
                "title": channel.title,
                "description": channel.description,
                "subscriber_count": (
                    channel.subscriber_count
                ),
                "bot_is_admin": (
                    channel.bot_is_admin
                ),
                "bot_permissions_verified": (
                    channel.bot_permissions_verified
                ),
                "owner_verified": (
                    channel.owner_verified
                ),
                "verification_status": (
                    channel.verification_status
                ),
                "created_at": channel.created_at,
            }
            for channel in channels
        ],
        "count": len(channels),
    }


# ============================================================
# APPROVE CHANNEL
# ============================================================

@router.post("/channels/{channel_id}/approve")
async def approve_channel(
    channel_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Approuve une chaîne après vérification.
    """

    result = await db.execute(
        select(Channel).where(
            Channel.id == channel_id
        )
    )

    channel = result.scalar_one_or_none()

    if channel is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Chaîne introuvable.",
        )

    if not channel.bot_is_admin:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Le bot NexMarket n'est pas "
                "administrateur de la chaîne."
            ),
        )

    if not channel.bot_permissions_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Les permissions du bot "
                "n'ont pas été vérifiées."
            ),
        )

    if not channel.owner_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Le propriétaire Telegram "
                "n'a pas été vérifié."
            ),
        )

    now = datetime.now(timezone.utc)

    channel.verification_status = "approved"
    channel.verified_at = now
    channel.verified_by_admin_id = current_admin.id
    channel.rejection_reason = None
    channel.is_active = True

    await db.commit()
    await db.refresh(channel)

    return {
        "status": "success",
        "channel_id": channel.id,
        "verification_status": (
            channel.verification_status
        ),
        "verified_at": channel.verified_at,
        "verified_by_admin_id": (
            channel.verified_by_admin_id
        ),
    }


# ============================================================
# REJECT CHANNEL
# ============================================================

@router.post("/channels/{channel_id}/reject")
async def reject_channel(
    channel_id: int,
    payload: RejectRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Rejette une chaîne.
    """

    cleaned_reason = payload.reason.strip()

    if not cleaned_reason:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Le motif du rejet est obligatoire.",
        )

    result = await db.execute(
        select(Channel).where(
            Channel.id == channel_id
        )
    )

    channel = result.scalar_one_or_none()

    if channel is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Chaîne introuvable.",
        )

    channel.verification_status = "rejected"
    channel.verified_by_admin_id = current_admin.id
    channel.rejection_reason = cleaned_reason
    channel.is_listed = False

    await db.commit()
    await db.refresh(channel)

    return {
        "status": "success",
        "channel_id": channel.id,
        "verification_status": (
            channel.verification_status
        ),
        "rejection_reason": (
            channel.rejection_reason
        ),
    }


# ============================================================
# LISTINGS - PENDING
# ============================================================

@router.get("/listings/pending")
async def pending_listings(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Liste les annonces en attente de modération, avec le canal, le vendeur
    et le nombre de photos de preuve (pour décider sans ouvrir chaque fiche).
    """

    rows = (
        await db.execute(
            select(Listing, Channel, User)
            .join(Channel, Channel.id == Listing.channel_id)
            .join(User, User.id == Listing.seller_id)
            .where(Listing.status == "pending_review")
            .order_by(Listing.created_at.asc())
        )
    ).all()

    proof_counts = dict(
        (
            await db.execute(
                select(ListingProof.listing_id, func.count())
                .where(
                    ListingProof.listing_id.in_([row[0].id for row in rows])
                )
                .group_by(ListingProof.listing_id)
            )
        ).all()
    ) if rows else {}

    return {
        "listings": [
            {
                "id": listing.id,
                "channel_id": listing.channel_id,
                "price": listing.price,
                "currency": listing.currency,
                "title": listing.title,
                "description": listing.description,
                "category": listing.category,
                "status": listing.status,
                "platform_fee_rate": listing.platform_fee_rate,
                "created_at": listing.created_at,
                "proofs_count": proof_counts.get(listing.id, 0),
                "channel": {
                    "title": channel.title,
                    "telegram_username": channel.telegram_username,
                    "is_private": not bool(channel.telegram_username),
                    "subscriber_count": channel.subscriber_count,
                },
                "seller": {
                    "id": seller.id,
                    "name": (
                        " ".join(
                            part
                            for part in (seller.first_name, seller.last_name)
                            if part
                        )
                        or seller.username
                        or seller.nexa_id
                    ),
                    "nexa_id": seller.nexa_id,
                },
            }
            for listing, channel, seller in rows
        ],
        "count": len(rows),
    }


# ============================================================
# APPROVE LISTING
# ============================================================

@router.post("/listings/{listing_id}/approve")
async def approve_listing(
    listing_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
    without_proofs: bool = False,
):
    """
    Approuve et publie une annonce.
    """

    result = await db.execute(
        select(Listing).where(
            Listing.id == listing_id
        )
    )

    listing = result.scalar_one_or_none()

    if listing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Annonce introuvable.",
        )

    # Les photos de preuve (envoyées par le vendeur) doivent exister.
    proofs_count = await db.scalar(
        select(func.count())
        .select_from(ListingProof)
        .where(ListingProof.listing_id == listing_id)
    )

    if not proofs_count and not without_proofs:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Aucune photo de preuve n'a été fournie pour cette annonce. "
                "Demandez-les au vendeur, ou approuvez quand même en "
                "confirmant."
            ),
        )

    channel_result = await db.execute(
        select(Channel).where(
            Channel.id == listing.channel_id
        )
    )

    channel = channel_result.scalar_one_or_none()

    if channel is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Chaîne associée introuvable.",
        )

    # Le vendeur a soumis canal + annonce ensemble : valider l'annonce
    # approuve aussi le canal (s'il n'a pas été rejeté).
    if channel.verification_status not in ("submitted", "approved"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La chaîne associée n'est pas acceptable.",
        )

    if not channel.owner_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Le propriétaire de la chaîne "
                "n'est pas vérifié."
            ),
        )

    if not channel.bot_permissions_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Les permissions du bot "
                "ne sont pas vérifiées."
            ),
        )

    now = datetime.now(timezone.utc)

    # Première publication seulement : une annonce modifiée puis ré-approuvée
    # ne doit pas re-notifier tous les membres.
    first_publication = listing.published_at is None

    listing.status = "published"
    listing.is_public = True
    listing.reviewed_by_admin_id = current_admin.id
    listing.reviewed_at = now
    listing.rejection_reason = None
    listing.published_at = now

    channel.is_listed = True

    if channel.verification_status != "approved":
        channel.verification_status = "approved"
        channel.verified_at = now
        channel.verified_by_admin_id = current_admin.id
        channel.rejection_reason = None
        channel.is_active = True

    await db.commit()
    await db.refresh(listing)

    await notify_user_id(
        db,
        listing.seller_id,
        "✅ Votre annonce a été approuvée et est maintenant visible "
        "sur NexMarket.",
    )

    if first_publication:
        schedule_new_listing_broadcast(listing.id)

    return {
        "status": "success",
        "listing_id": listing.id,
        "listing_status": listing.status,
        "is_public": listing.is_public,
        "published_at": listing.published_at,
    }


# ============================================================
# REJECT LISTING
# ============================================================

@router.post("/listings/{listing_id}/reject")
async def reject_listing(
    listing_id: int,
    payload: RejectRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Rejette une annonce.
    """

    cleaned_reason = payload.reason.strip()

    if not cleaned_reason:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Le motif du rejet est obligatoire.",
        )

    result = await db.execute(
        select(Listing).where(
            Listing.id == listing_id
        )
    )

    listing = result.scalar_one_or_none()

    if listing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Annonce introuvable.",
        )

    listing.status = "rejected"
    listing.is_public = False
    listing.reviewed_by_admin_id = current_admin.id
    listing.reviewed_at = (
        datetime.now(timezone.utc)
    )
    listing.rejection_reason = cleaned_reason

    await db.commit()
    await db.refresh(listing)

    await notify_user_id(
        db,
        listing.seller_id,
        "❌ Votre annonce n'a pas été approuvée.\n\nMotif : "
        + cleaned_reason,
    )

    return {
        "status": "success",
        "listing_id": listing.id,
        "listing_status": listing.status,
        "is_public": listing.is_public,
        "rejection_reason": (
            listing.rejection_reason
        ),
    }


# ============================================================
# TRANSACTIONS - ACTIVE
# ============================================================

@router.get("/transactions")
async def admin_transactions(
    current_admin: CurrentAdmin,
    db: DBSession,
    transaction_status: str | None = None,
):
    """
    Liste les transactions pour l'administration.
    """

    query = select(Transaction)

    if transaction_status:
        query = query.where(
            Transaction.status == transaction_status
        )

    query = query.order_by(
        Transaction.created_at.desc()
    )

    result = await db.execute(query)

    transactions = result.scalars().all()

    return {
        "transactions": [
            {
                "id": transaction.id,
                "reference": transaction.reference,
                "listing_id": transaction.listing_id,
                "buyer_id": transaction.buyer_id,
                "seller_id": transaction.seller_id,
                "assigned_admin_id": (
                    transaction.assigned_admin_id
                ),
                "channel_price": (
                    transaction.channel_price
                ),
                "platform_fee": (
                    transaction.platform_fee
                ),
                "provider_fee": (
                    transaction.provider_fee
                ),
                "total_buyer_amount": (
                    transaction.total_buyer_amount
                ),
                "seller_amount": (
                    transaction.seller_amount
                ),
                "currency": transaction.currency,
                "status": transaction.status,
                "payment_provider": (
                    transaction.payment_provider
                ),
                "payment_status": (
                    transaction.payment_status
                ),
                "escrow_held": (
                    transaction.escrow_held
                ),
                "protection_ends_at": (
                    transaction.protection_ends_at
                ),
                "disputed_at": (
                    transaction.disputed_at
                ),
                "created_at": transaction.created_at,
            }
            for transaction in transactions
        ],
        "count": len(transactions),
    }


# ============================================================
# ASSIGN TRANSACTION
# ============================================================

@router.post(
    "/transactions/{transaction_id}/assign"
)
async def assign_transaction(
    transaction_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Assigne une transaction à l'admin connecté.
    """

    result = await db.execute(
        select(Transaction).where(
            Transaction.id == transaction_id
        )
    )

    transaction = result.scalar_one_or_none()

    if transaction is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transaction introuvable.",
        )

    transaction.assigned_admin_id = (
        current_admin.id
    )

    await db.commit()
    await db.refresh(transaction)

    return {
        "status": "success",
        "transaction_id": transaction.id,
        "assigned_admin_id": (
            transaction.assigned_admin_id
        ),
    }


# ============================================================
# REPORTS
# ============================================================

@router.get("/reports")
async def admin_reports(
    current_admin: CurrentAdmin,
    db: DBSession,
    report_status: str | None = None,
):
    """
    Liste les signalements.
    """

    query = select(Report)

    if report_status:
        query = query.where(
            Report.status == report_status
        )

    query = query.order_by(
        Report.created_at.desc()
    )

    result = await db.execute(query)

    reports = result.scalars().all()

    return {
        "reports": [
            {
                "id": report.id,
                "transaction_id": (
                    report.transaction_id
                ),
                "reporter_id": (
                    report.reporter_id
                ),
                "report_type": (
                    report.report_type
                ),
                "reason": report.reason,
                "status": report.status,
                "assigned_admin_id": (
                    report.assigned_admin_id
                ),
                "admin_resolution": (
                    report.admin_resolution
                ),
                "resolved_at": report.resolved_at,
                "created_at": report.created_at,
            }
            for report in reports
        ],
        "count": len(reports),
    }


# ============================================================
# WALLET / PLATFORM OVERVIEW
# ============================================================

@router.get("/wallets")
async def admin_wallets(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Vue des soldes des wallets utilisateurs.

    Aucun numéro MoneyFusion privé n'est retourné.
    """

    result = await db.execute(
        select(Wallet)
        .order_by(
            Wallet.created_at.desc()
        )
    )

    wallets = result.scalars().all()

    return {
        "wallets": [
            {
                "id": wallet.id,
                "user_id": wallet.user_id,
                "available_balance": (
                    wallet.available_balance
                ),
                "blocked_balance": (
                    wallet.blocked_balance
                ),
                "total_revenue": (
                    wallet.total_revenue
                ),
                "currency": wallet.currency,
                "created_at": wallet.created_at,
                "updated_at": wallet.updated_at,
            }
            for wallet in wallets
        ],
        "count": len(wallets),
    }


# ============================================================
# ADMIN : SESSION
# ============================================================

@router.get("/me")
async def admin_me(current_admin: CurrentAdmin):
    return {
        "id": current_admin.id,
        "telegram_id": current_admin.telegram_id,
        "username": current_admin.username,
        "is_admin": True,
    }


# ============================================================
# ALL CHANNELS
# ============================================================

@router.get("/channels")
async def list_all_channels(
    current_admin: CurrentAdmin,
    db: DBSession,
    limit: int = 100,
):
    limit = max(1, min(limit, 200))

    channels = (
        await db.execute(
            select(Channel)
            .order_by(Channel.created_at.desc())
            .limit(limit)
        )
    ).scalars().all()

    return {
        "channels": [
            {
                "id": c.id,
                "telegram_username": c.telegram_username,
                "title": c.title,
                "subscriber_count": c.subscriber_count,
                "bot_is_admin": c.bot_is_admin,
                "owner_verified": c.owner_verified,
                "verification_status": c.verification_status,
                "is_active": c.is_active,
                "is_private": not bool(c.telegram_username),
                "telegram_channel_id": c.telegram_channel_id,
                "is_listed": c.is_listed,
                "owner_id": c.owner_id,
                "created_at": c.created_at,
            }
            for c in channels
        ]
    }


# ============================================================
# ONE LISTING (détail)
# ============================================================

@router.get("/listings/{listing_id}")
async def get_listing_detail(
    listing_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    row = (
        await db.execute(
            select(Listing, Channel)
            .join(Channel, Listing.channel_id == Channel.id)
            .where(Listing.id == listing_id)
        )
    ).first()

    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Annonce introuvable.",
        )

    listing, channel = row

    proof_ids = (
        await db.execute(
            select(ListingProof.id)
            .where(ListingProof.listing_id == listing_id)
            .order_by(ListingProof.id)
        )
    ).scalars().all()

    return {
        "id": listing.id,
        "title": listing.title,
        "description": listing.description,
        "category": listing.category,
        "price": listing.price,
        "currency": listing.currency,
        "status": listing.status,
        "is_public": listing.is_public,
        "rejection_reason": listing.rejection_reason,
        "seller_id": listing.seller_id,
        "created_at": listing.created_at,
        "proofs": [{"id": proof_id} for proof_id in proof_ids],
        "channel": {
            "id": channel.id,
            "title": channel.title,
            "telegram_username": channel.telegram_username,
            "subscriber_count": channel.subscriber_count,
            "bot_is_admin": channel.bot_is_admin,
            "bot_permissions_verified": channel.bot_permissions_verified,
            "owner_verified": channel.owner_verified,
            "verification_status": channel.verification_status,
        },
    }


# ============================================================
# MESSAGES (supervision des discussions de transaction)
# ============================================================

@router.get("/messages")
async def list_recent_messages(
    current_admin: CurrentAdmin,
    db: DBSession,
    limit: int = 100,
):
    limit = max(1, min(limit, 200))

    messages = (
        await db.execute(
            select(Message)
            .where(Message.is_deleted.is_(False))
            .order_by(Message.created_at.desc())
            .limit(limit)
        )
    ).scalars().all()

    return {
        "messages": [
            {
                "id": m.id,
                "transaction_id": m.transaction_id,
                "sender_id": m.sender_id,
                "sender_role": m.sender_role,
                "content": m.content,
                "created_at": m.created_at,
            }
            for m in messages
        ]
    }


# ============================================================
# PLATFORM WALLET (commissions)
# ============================================================

@router.get("/platform-wallet")
async def platform_wallet(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    wallets = (
        await db.execute(select(PlatformWallet))
    ).scalars().all()

    return {
        "wallets": [
            {
                "currency": w.currency,
                "available_balance": w.available_balance,
                "total_revenue": w.total_revenue,
                "total_fees_collected": w.total_fees_collected,
            }
            for w in wallets
        ]
    }


# ============================================================
# RETRAITS AU STATUT INCONNU (pas de webhook)
# ============================================================

@router.get("/withdrawals")
async def list_withdrawals(
    current_admin: CurrentAdmin,
    db: DBSession,
    status_filter: str = "processing",
    limit: int = 100,
):
    """Retraits à vérifier (par défaut : « processing »)."""

    limit = max(1, min(limit, 200))

    rows = (
        await db.execute(
            select(Withdrawal)
            .where(Withdrawal.status == status_filter)
            .order_by(Withdrawal.created_at.desc())
            .limit(limit)
        )
    ).scalars().all()

    return {
        "withdrawals": [
            {
                "id": w.id,
                "reference": w.reference,
                "user_id": w.user_id,
                "amount": w.amount,
                "currency": w.currency,
                "destination": (
                    f"{(w.payout_country or '').upper()} · {w.payout_method or ''} · {w.payout_phone or ''}"
                    if w.payout_method
                    else (w.jessikapay_jp_number or "")
                ),
                "country": w.payout_country,
                "method": w.payout_method,
                "phone": w.payout_phone,
                "payout_amount": w.payout_amount,
                "payout_currency": w.payout_currency,
                "tracked": bool(w.jessikapay_transaction_id),
                "status": w.status,
                "failure_reason": w.failure_reason,
                "created_at": w.created_at,
            }
            for w in rows
        ]
    }


@router.post("/withdrawals/{withdrawal_id}/recheck")
async def recheck_withdrawal(
    withdrawal_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """Relit tout de suite le statut chez MoneyFusion (retrait « processing » avec jeton)."""

    new_status = await sync_withdrawal(db, withdrawal_id)

    if new_status == "unknown":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Retrait introuvable.")

    return {"id": withdrawal_id, "status": new_status}


@router.post("/withdrawals/{withdrawal_id}/resolve")
async def resolve_withdrawal(
    withdrawal_id: int,
    payload: WithdrawalResolveRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Tranche un retrait dont l'issue est inconnue, APRÈS avoir vérifié
    dans MoneyFusion si le versement a bien été fait :
      - complete : le versement a eu lieu -> les fonds bloqués sont consommés ;
      - fail     : il n'a pas eu lieu     -> les fonds sont rendus à l'utilisateur.
    """

    withdrawal = (
        await db.execute(
            select(Withdrawal)
            .where(Withdrawal.id == withdrawal_id)
            .with_for_update()
        )
    ).scalar_one_or_none()

    if withdrawal is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Retrait introuvable.",
        )

    if withdrawal.status not in ("processing", "pending"):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ce retrait est déjà « {withdrawal.status} ».",
        )

    withdrawal.reviewed_by_admin_id = current_admin.id
    withdrawal.admin_note = payload.note

    if payload.action == "complete":
        await complete_withdrawal(db, withdrawal)
        await money_notifications.withdrawal_completed(db, withdrawal)
    else:
        reason = payload.note or "Retrait non effectué (décision admin)."
        await fail_withdrawal(db, withdrawal, reason)
        await money_notifications.withdrawal_failed(db, withdrawal, reason)

    return {"id": withdrawal.id, "status": withdrawal.status}


# ============================================================
# DÉPÔTS (diagnostic + crédit manuel)
# ============================================================

@router.get("/deposits")
async def list_deposits(
    current_admin: CurrentAdmin,
    db: DBSession,
    status_filter: str = "",
    limit: int = 100,
):
    """Derniers dépôts (tous les statuts par défaut)."""

    limit = max(1, min(limit, 200))

    query = (
        select(Deposit, User)
        .join(User, User.id == Deposit.user_id)
        .order_by(Deposit.created_at.desc())
        .limit(limit)
    )

    if status_filter:
        query = query.where(Deposit.status == status_filter)

    rows = (await db.execute(query)).all()

    return {
        "deposits": [
            {
                "id": d.id,
                "reference": d.reference,
                "user": (u.username and f"@{u.username}") or u.first_name or f"#{u.id}",
                "nexa_id": u.nexa_id,
                "amount": d.amount,
                "currency": d.currency,
                "country": d.country,
                "phone": d.phone,
                "status": d.status,
                "failure_reason": d.failure_reason,
                "created_at": d.created_at,
                "paid_at": d.paid_at,
            }
            for d, u in rows
        ]
    }


@router.post("/deposits/{deposit_id}/recheck")
async def recheck_deposit(
    deposit_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Interroge MoneyFusion à nouveau (même pour un dépôt classé en échec)
    et renvoie la RÉPONSE BRUTE du prestataire pour comprendre le blocage.
    """

    deposit = (
        await db.execute(select(Deposit).where(Deposit.id == deposit_id))
    ).scalar_one_or_none()

    if deposit is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dépôt introuvable.")

    try:
        provider = await jessikapay_service.get_payment_status(deposit.jessikapay_request_id)
    except MoneyFusionError as exc:
        provider = {"error": str(exc)}

    new_status = await sync_deposit(db, deposit_id, force=True)

    return {"id": deposit_id, "status": new_status, "paid": new_status == "paid", "provider": provider}


class DepositCreditRequest(BaseModel):
    note: str = ""


@router.post("/deposits/{deposit_id}/credit")
async def credit_deposit(
    deposit_id: int,
    payload: DepositCreditRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Crédite le wallet de l'utilisateur APRÈS avoir vérifié dans
    MoneyFusion que le paiement a bien été reçu. Sans double crédit.
    """

    result = await credit_deposit_manually(
        db, deposit_id, current_admin.id, (payload.note or "").strip()[:200]
    )

    if result == "unknown":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dépôt introuvable.")

    return {"id": deposit_id, "status": result, "paid": result == "paid"}


# ============================================================
# AJUSTEMENT MANUEL DU PORTEFEUILLE (crédit / retrait par un admin)
# ============================================================

class WalletAdjustRequest(BaseModel):
    action: str  # "credit" ou "debit"
    amount: int
    note: str = ""


@router.post("/wallets/{user_id}/adjust")
async def adjust_wallet(
    user_id: int,
    payload: WalletAdjustRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """Crédite ou débite le portefeuille NexMarket d'un utilisateur.

    Chaque ajustement est tracé (référence ADM-…, note, admin) dans
    l'historique du wallet. Un retrait ne peut pas dépasser le solde disponible.
    """

    import logging
    from decimal import Decimal
    from uuid import uuid4

    from app.services.wallet_service import WalletService, WalletServiceError

    action = (payload.action or "").strip().lower()
    note = (payload.note or "").strip()[:200]

    if action not in {"credit", "debit"}:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Action invalide (credit ou debit).")

    if payload.amount <= 0 or payload.amount > 100_000_000:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Montant invalide.")

    if not note:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Ajoute une note : elle est conservée dans l'historique.")

    target = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()

    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Utilisateur introuvable.")

    service = WalletService(db)
    reference = "ADM-" + uuid4().hex[:20].upper()
    description = f"Admin #{current_admin.id} : {note}"
    amount = Decimal(payload.amount)

    try:
        if action == "credit":
            wallet = await service.credit(
                user_id=user_id, amount=amount, reference=reference,
                operation_type="admin_credit", description=description,
            )
        else:
            wallet = await service.debit(
                user_id=user_id, amount=amount, reference=reference,
                operation_type="admin_debit", description=description,
            )
    except WalletServiceError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc

    logging.getLogger("nexmarket.admin").warning(
        "Wallet %s %s %s XAF par admin %s (%s)", user_id, action, payload.amount, current_admin.id, note,
    )

    verb = "crédité de" if action == "credit" else "débité de"
    await notify_user_id(
        db, user_id,
        f"ℹ️ Ton portefeuille NexMarket a été {verb} {payload.amount} XAF par l'administration.\n\nMotif : {note}",
    )

    return {
        "reference": reference,
        "action": action,
        "amount": payload.amount,
        "available_balance": float(wallet.available_balance),
    }


# ============================================================
# COMMISSIONS vers le compte MoneyFusion NexMarket
# ============================================================

class CommissionResolveRequest(BaseModel):
    action: str  # "sent" (déjà reçue dans MoneyFusion) ou "retry" (non reçue)
    note: str = ""


@router.get("/commissions")
async def list_commissions(
    current_admin: CurrentAdmin,
    db: DBSession,
    status_filter: str = "",
    limit: int = 100,
):
    """Commissions à verser / à vérifier (tous statuts par défaut)."""

    limit = max(1, min(limit, 200))

    query = select(CommissionPayout).order_by(CommissionPayout.id.desc()).limit(limit)

    if status_filter:
        query = query.where(CommissionPayout.status == status_filter)

    rows = (await db.execute(query)).scalars().all()

    return {
        "commissions": [
            {
                "id": c.id,
                "transaction_id": c.transaction_id,
                "reference": c.reference,
                "amount": c.amount,
                "currency": c.currency,
                "status": c.status,
                "attempts": c.attempts,
                "failure_reason": c.failure_reason,
                "created_at": c.created_at,
                "sent_at": c.sent_at,
            }
            for c in rows
        ]
    }


@router.post("/commissions/{commission_id}/resolve")
async def resolve_commission(
    commission_id: int,
    payload: CommissionResolveRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Tranche une commission « processing / failed / manual » APRÈS avoir
    vérifié dans MoneyFusion :
      - sent  : la commission est bien arrivée -> marquée versée ;
      - retry : elle n'est PAS arrivée -> remise en file d'envoi.
    """

    row = (
        await db.execute(
            select(CommissionPayout)
            .where(CommissionPayout.id == commission_id)
            .with_for_update()
        )
    ).scalar_one_or_none()

    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Commission introuvable.")

    if row.status in ("sent", "pending", "sending"):
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"Cette commission est déjà « {row.status} ».",
        )

    note = (payload.note or "").strip()[:200]

    if payload.action == "sent":
        row.status = "sent"
        row.sent_at = datetime.utcnow()
        row.failure_reason = f"Confirmée par admin #{current_admin.id}" + (f" : {note}" if note else "")
    elif payload.action == "retry":
        row.status = "pending"
        row.attempts = 0
        row.failure_reason = f"Renvoi demandé par admin #{current_admin.id}" + (f" : {note}" if note else "")
    else:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Action invalide (sent ou retry).")

    await db.commit()

    return {"id": row.id, "status": row.status}


class AdminAddRequest(BaseModel):
    telegram_id: int


def _require_primary_admin(current_admin: User) -> None:
    """Seul l'administrateur principal (ADMIN_TELEGRAM_ID) gère les admins."""

    primary = int(settings.ADMIN_TELEGRAM_ID or 0)

    if not primary or int(current_admin.telegram_id) != primary:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Seul l'administrateur principal peut ajouter ou retirer des administrateurs.",
        )


@router.post("/admins")
async def add_admin(
    payload: AdminAddRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """Promeut un utilisateur (qui a déjà fait /start sur le bot) en admin."""

    _require_primary_admin(current_admin)

    user = (
        await db.execute(select(User).where(User.telegram_id == payload.telegram_id))
    ).scalar_one_or_none()

    if user is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "Utilisateur introuvable : il doit d'abord envoyer /start au bot.",
        )

    user.is_admin = True
    user.is_active = True
    await db.commit()

    return {"telegram_id": user.telegram_id, "is_admin": True}


@router.delete("/admins/{telegram_id}")
async def remove_admin(
    telegram_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    _require_primary_admin(current_admin)

    if telegram_id == int(settings.ADMIN_TELEGRAM_ID or 0):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "L'administrateur principal ne peut pas être retiré.",
        )

    user = (
        await db.execute(select(User).where(User.telegram_id == telegram_id))
    ).scalar_one_or_none()

    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Utilisateur introuvable.")

    user.is_admin = False
    await db.commit()

    return {"telegram_id": telegram_id, "is_admin": False}


# ============================================================
# GRAM À LIBÉRER / À REMBOURSER (paiement en GRAM, TON)
# ============================================================

class GramSentRequest(BaseModel):
    tx_hash: str
    # À n'utiliser que si la blockchain est injoignable : l'admin confirme
    # l'envoi sans vérification automatique (tracé dans la transaction).
    unverified: bool = False


@router.get("/gram/tasks")
async def gram_tasks(current_admin: CurrentAdmin, db: DBSession):
    """GRAM à envoyer par l'administrateur (vendeurs ou remboursements)."""

    return {
        "enabled": gram_service.enabled(),
        "address": settings.GRAM_RECEIVE_ADDRESS.strip() if gram_service.enabled() else None,
        "tasks": await gram_service.list_tasks(db),
    }


@router.post("/gram/{transaction_id}/sent")
async def gram_sent(
    transaction_id: int,
    payload: GramSentRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """L'admin a envoyé les GRAM : on vérifie sur la blockchain puis on clôt."""

    try:
        transaction = await gram_service.mark_sent(
            db,
            transaction_id,
            current_admin.id,
            payload.tx_hash,
            unverified=payload.unverified,
        )
    except gram_service.GramError as exc:
        await db.rollback()
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc

    return {"id": transaction.id, "status": transaction.status, "escrow_held": transaction.escrow_held}


# ============================================================
# PHOTOS DE PREUVE (consultation par l'administrateur)
# ============================================================

@router.get("/proofs/{proof_id}")
async def get_proof_image(
    proof_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    proof = (
        await db.execute(
            select(ListingProof).where(ListingProof.id == proof_id)
        )
    ).scalar_one_or_none()

    if proof is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Photo introuvable.",
        )

    return Response(
        content=proof.data,
        media_type=proof.content_type,
        headers={"Cache-Control": "private, max-age=3600"},
    )


# ============================================================
# SUPPRIMER UN CANAL
# ============================================================

ACTIVE_TRANSACTION_STATUSES = (
    "pending_payment",
    "waiting_admin",
    "transfer_started",
    "protection_period",
    "disputed",
)


@router.delete("/channels/{channel_id}")
async def remove_channel(
    channel_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
    ban: bool = False,
):
    """
    Retire un canal de la vente : ses annonces sont annulées et il n'est
    plus visible.

    - ban=false (défaut) : retrait RÉVERSIBLE (statut « withdrawn »). Le
      vendeur peut soumettre à nouveau son canal quand il veut.
    - ban=true : bannissement DÉFINITIF (statut « removed »), pour les
      canaux frauduleux. Il ne peut plus jamais être remis en vente.

    L'historique des transactions terminées est conservé.
    """

    channel = (
        await db.execute(
            select(Channel)
            .where(Channel.id == channel_id)
            .with_for_update()
        )
    ).scalar_one_or_none()

    if channel is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Canal introuvable.",
        )

    active = await db.scalar(
        select(func.count())
        .select_from(Transaction)
        .join(Listing, Listing.id == Transaction.listing_id)
        .where(
            Listing.channel_id == channel.id,
            Transaction.status.in_(ACTIVE_TRANSACTION_STATUSES),
        )
    )

    if active:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Des transactions sont en cours sur ce canal : "
                "résolvez-les avant de le supprimer."
            ),
        )

    listings = (
        await db.execute(
            select(Listing).where(Listing.channel_id == channel.id)
        )
    ).scalars().all()

    cancelled = 0

    for listing in listings:
        if listing.status not in ("sold", "cancelled"):
            listing.status = "cancelled"
            cancelled += 1

        listing.is_public = False

    channel.is_active = False
    channel.is_listed = False
    channel.verification_status = "removed" if ban else "withdrawn"

    title = channel.title
    owner_id = channel.owner_id

    await db.commit()

    await notify_user_id(
        db,
        owner_id,
        (
            f"⛔ Votre canal « {title} » a été banni de NexMarket par "
            "l'administration. Il ne peut plus être remis en vente."
            if ban
            else f"ℹ️ Votre canal « {title} » a été retiré de la vente par "
            "l'administration. Vous pouvez le soumettre à nouveau "
            "quand vous voulez."
        ),
    )

    return {
        "status": "success",
        "channel_id": channel_id,
        "listings_cancelled": cancelled,
        "banned": ban,
    }


# ============================================================
# RETIRER UN UTILISATEUR DE LA MARKETPLACE
# ============================================================

@router.post("/users/{user_id}/remove")
async def remove_user(
    user_id: int,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    """
    Bloque le compte ET retire ses annonces et ses canaux de la
    marketplace. Les comptes ne sont jamais effacés de la base : l'historique
    financier (dépôts, retraits, transactions) doit rester traçable.
    """

    user = (
        await db.execute(select(User).where(User.id == user_id))
    ).scalar_one_or_none()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Utilisateur introuvable.",
        )

    if user.id == current_admin.id or user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Un administrateur ne peut pas être retiré.",
        )

    active = await db.scalar(
        select(func.count())
        .select_from(Transaction)
        .where(
            or_(
                Transaction.buyer_id == user.id,
                Transaction.seller_id == user.id,
            ),
            Transaction.status.in_(ACTIVE_TRANSACTION_STATUSES),
        )
    )

    if active:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Cet utilisateur a des transactions en cours : "
                "résolvez-les d'abord."
            ),
        )

    listings = (
        await db.execute(
            select(Listing).where(
                Listing.seller_id == user.id,
                Listing.status.notin_(("sold", "cancelled")),
            )
        )
    ).scalars().all()

    for listing in listings:
        listing.status = "cancelled"
        listing.is_public = False

    channels = (
        await db.execute(
            select(Channel).where(Channel.owner_id == user.id)
        )
    ).scalars().all()

    for channel in channels:
        channel.is_active = False
        channel.is_listed = False

    user.is_active = False

    await db.commit()

    return {
        "status": "success",
        "user_id": user.id,
        "listings_cancelled": len(listings),
        "channels_removed": len(channels),
    }


# ============================================================
# ANNONCE À TOUS LES UTILISATEURS (via le bot)
# ============================================================

async def _broadcast(admin_chat_id: int, chat_ids: list[int], text: str) -> None:
    bot = get_telegram_service().bot
    sent = failed = 0

    for chat_id in chat_ids:
        try:
            await bot.send_message(chat_id=chat_id, text=text)
            sent += 1
        except Exception:
            # utilisateur qui a bloqué le bot / jamais démarré le bot
            failed += 1

        await asyncio.sleep(0.06)  # ~16 messages/s : sous la limite Telegram

    try:
        await bot.send_message(
            chat_id=admin_chat_id,
            text=f"📢 Annonce terminée : {sent} envoyé(s), {failed} non distribué(s).",
        )
    except Exception:
        pass


_broadcast_tasks: set = set()


@router.post("/announcements")
async def send_announcement(
    payload: AnnouncementRequest,
    current_admin: CurrentAdmin,
    db: DBSession,
):
    if payload.audience == "me":
        chat_ids = [current_admin.telegram_id]
    else:
        chat_ids = [
            int(value)
            for (value,) in (
                await db.execute(
                    select(User.telegram_id).where(User.is_active.is_(True))
                )
            ).all()
        ]

    task = asyncio.get_running_loop().create_task(
        _broadcast(
            current_admin.telegram_id,
            chat_ids,
            "📢 NexMarket\n\n" + payload.text.strip(),
        )
    )
    _broadcast_tasks.add(task)
    task.add_done_callback(_broadcast_tasks.discard)

    return {"status": "queued", "recipients": len(chat_ids)}


# ============================================================
# ADMINISTRATEURS
# ============================================================

@router.get("/admins")
async def list_admins(
    current_admin: CurrentAdmin,
    db: DBSession,
):
    rows = (
        await db.execute(
            select(User)
            .where(
                or_(
                    User.is_admin.is_(True),
                    User.telegram_id == int(settings.ADMIN_TELEGRAM_ID or 0),
                )
            )
            .order_by(User.created_at)
        )
    ).scalars().all()

    return {
        "admins": [
            {
                "id": user.id,
                "telegram_id": user.telegram_id,
                "nexa_id": user.nexa_id,
                "name": " ".join(
                    part for part in (user.first_name, user.last_name) if part
                ) or user.username,
                "username": user.username,
                "is_primary": bool(
                    settings.ADMIN_TELEGRAM_ID
                    and user.telegram_id == int(settings.ADMIN_TELEGRAM_ID)
                ),
            }
            for user in rows
        ]
    }
