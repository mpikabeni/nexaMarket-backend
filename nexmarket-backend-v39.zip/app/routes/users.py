import re
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Response, status

from app.config import settings
from app.services.telegram_service import get_telegram_service
from app.services.wallet_service import WalletService
from app.deps import CurrentUser, DBSession
from app.models.schemas import OnboardingIn, UserResponse, UserUpdate


router = APIRouter(
    prefix="/users",
    tags=["Users"],
)


# ============================================================
# GET MY PROFILE
# ============================================================

@router.get(
    "/me",
    response_model=UserResponse,
)
async def get_my_profile(
    current_user: CurrentUser,
):
    """
    Retourne le profil de l'utilisateur connecté.
    """

    return current_user


# ============================================================
# UPDATE MY PROFILE
# ============================================================

@router.patch(
    "/me",
    response_model=UserResponse,
)
async def update_my_profile(
    payload: UserUpdate,
    current_user: CurrentUser,
    db: DBSession,
):
    """
    Met à jour les préférences du profil.

    Les informations d'identité Telegram ne doivent pas
    être utilisées pour modifier l'identité réelle du compte.
    """

    data = payload.model_dump(
        exclude_unset=True
    )

    # --------------------------------------------------------
    # Champs autorisés
    # --------------------------------------------------------

    allowed_fields = {
        "language",
        "preferred_currency",
    }

    # On ne permet pas au frontend de modifier :
    # - telegram_id
    # - nexa_id
    # - is_admin
    # - is_active
    # - identité Telegram
    # - photo Telegram
    #
    # Ces données sont contrôlées par le backend/Telegram.

    for field in data:
        if field not in allowed_fields:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Le champ '{field}' "
                    "ne peut pas être modifié."
                ),
            )

    # --------------------------------------------------------
    # Language
    # --------------------------------------------------------

    if "language" in data:
        language = data["language"]

        if language is not None:
            language = language.strip().lower()

            if len(language) > 10:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Langue invalide.",
                )

            current_user.language = language

    # --------------------------------------------------------
    # Currency
    # --------------------------------------------------------

    if "preferred_currency" in data:
        currency = data[
            "preferred_currency"
        ]

        if currency is not None:
            currency = currency.strip().upper()

            supported_currencies = set(
                settings.get_supported_currencies()
            )

            if currency not in supported_currencies:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        "Devise non supportée. "
                        f"Devises disponibles : "
                        f"{', '.join(sorted(supported_currencies))}"
                    ),
                )

            current_user.preferred_currency = (
                currency
            )

    await db.commit()
    await db.refresh(current_user)

    return current_user


# ============================================================
# GET MY WALLET SUMMARY
# ============================================================

# ============================================================
# INSCRIPTION EN 3 ÉTAPES (profil, pays + numéro, sécurité)
# ============================================================

@router.post("/me/onboarding", response_model=UserResponse)
async def complete_onboarding(
    payload: OnboardingIn,
    current_user: CurrentUser,
    db: DBSession,
):
    """Enregistre le pays, le numéro Mobile Money et l'acceptation des conditions."""

    country = payload.country.strip().upper()
    phone = re.sub(r"\D", "", payload.phone)

    if not re.fullmatch(r"[A-Z]{2}", country):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Pays invalide.")

    if country in {"RU", "IN"}:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "NexMarket n'est pas disponible dans ton pays.",
        )

    if not 6 <= len(phone) <= 15:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Numéro invalide.")

    if not payload.accept_terms:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Tu dois accepter les conditions pour créer ton compte.",
        )

    current_user.country = country
    current_user.phone = phone

    first_time = current_user.onboarded_at is None

    if first_time:
        current_user.onboarded_at = datetime.now(timezone.utc)

    await db.commit()
    await db.refresh(current_user)

    if first_time:
        # Le NEXA ID est remis dans le bot UNE FOIS le compte créé.
        try:
            from app.services.money_notifications import notify_user_id

            await notify_user_id(
                db,
                current_user.id,
                "🎉 <b>Compte créé !</b>\n\n"
                "🆔 <b>Ton NEXA ID</b>\n"
                f"<code>{current_user.nexa_id}</code>\n\n"
                "Tu peux maintenant acheter et vendre des canaux sur NexMarket.",
            )
        except Exception:
            pass

    return current_user


@router.get("/me/wallet")
async def get_my_wallet(
    current_user: CurrentUser,
    db: DBSession,
):
    """
    Retourne le wallet de l'utilisateur connecté.
    """

    # Avant : `current_user.wallet` (relation chargée paresseusement)
    # lève MissingGreenlet en contexte async => erreur 500.
    # Le wallet est lu (ou créé s'il manque) via le service.
    wallet = await WalletService(db).get_wallet(current_user.id)

    return {
        "id": wallet.id,
        "available_balance": (
            wallet.available_balance
        ),
        "blocked_balance": (
            wallet.blocked_balance
        ),
        "total_revenue": (
            wallet.total_revenue
        ),
        "currency": wallet.currency,
        "created_at": wallet.created_at,
        "updated_at": wallet.updated_at,
    }


# ============================================================
# PHOTO DE PROFIL (secours)
# ============================================================

@router.get("/me/photo")
async def my_photo(current_user: CurrentUser):
    """
    Photo Telegram de l'utilisateur connecté, récupérée via le bot.
    Utilisée par le frontend quand Telegram ne fournit pas `photo_url`
    (ou quand ce lien ne s'affiche pas). Nécessite le JWT : le frontend
    la charge avec fetch() puis l'affiche.
    """

    data = await get_telegram_service().fetch_user_photo(
        current_user.telegram_id
    )

    if not data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Aucune photo de profil disponible.",
        )

    return Response(
        content=data,
        media_type="image/jpeg",
        headers={"Cache-Control": "private, max-age=3600"},
    )
