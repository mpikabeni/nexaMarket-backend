# backend/app/models/transaction.py

from datetime import datetime
from decimal import Decimal

from datetime import timezone
from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Transaction(Base):
    __tablename__ = "transactions"

    # =========================================================
    # IDENTIFICATION
    # =========================================================

    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    reference: Mapped[str] = mapped_column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )

    # =========================================================
    # LISTING / USERS
    # =========================================================

    listing_id: Mapped[int] = mapped_column(
        ForeignKey("listings.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    buyer_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    seller_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    assigned_admin_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # =========================================================
    # AMOUNTS
    # =========================================================

    channel_price: Mapped[Decimal] = mapped_column(
        Numeric(18, 2),
        nullable=False,
    )

    platform_fee: Mapped[Decimal] = mapped_column(
        Numeric(18, 2),
        default=Decimal("0.00"),
        nullable=False,
    )

    provider_fee: Mapped[Decimal] = mapped_column(
        Numeric(18, 2),
        default=Decimal("0.00"),
        nullable=False,
    )

    total_buyer_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2),
        nullable=False,
    )

    seller_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2),
        nullable=False,
    )

    currency: Mapped[str] = mapped_column(
        String(10),
        default="XAF",
        nullable=False,
    )

    # =========================================================
    # STATUS
    # =========================================================

    status: Mapped[str] = mapped_column(
        String(40),
        default="pending_payment",
        nullable=False,
        index=True,
    )

    # =========================================================
    # PAYMENT
    # =========================================================

    payment_provider: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    payment_reference: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        index=True,
    )

    payment_status: Mapped[str] = mapped_column(
        String(40),
        default="pending",
        nullable=False,
        index=True,
    )

    # =========================================================
    # COMMISSION / PROVIDER / ESCROW / PAYOUT (champs utilisés
    # par TransactionService et l'admin)
    # =========================================================

    platform_fee_rate: Mapped[Decimal] = mapped_column(
        Numeric(8, 6),
        default=Decimal("0.050000"),
        nullable=False,
    )

    escrow_held: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    escrow_held_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    protection_ends_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    buyer_confirmed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    disputed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    dispute_resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    seller_paid_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Posé AVANT l'envoi du versement automatique au vendeur : jamais deux fois.
    seller_payout_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    nexmarket_fee_recorded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    refunded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    refund_reference: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    # =========================================================
    # TELEGRAM TRANSFER
    # =========================================================

    telegram_chat_id: Mapped[int | None] = mapped_column(
        BigInteger,
        nullable=True,
        index=True,
    )

    transfer_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    transfer_completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # =========================================================
    # ADMIN / DISPUTE
    # =========================================================

    # ========================================================
    # PAIEMENT EN GRAM (TON)
    # ========================================================

    # Adresses fournies par l'acheteur (remboursement) et le vendeur (paiement).
    buyer_gram_address: Mapped[str | None] = mapped_column(
        String(80), nullable=True
    )
    seller_gram_address: Mapped[str | None] = mapped_column(
        String(80), nullable=True
    )
    # Hash du virement reçu de l'acheteur / de l'envoi fait au vendeur
    # (ou du remboursement) par l'administrateur.
    gram_tx_hash: Mapped[str | None] = mapped_column(
        String(120), nullable=True, index=True
    )
    gram_release_tx_hash: Mapped[str | None] = mapped_column(
        String(120), nullable=True
    )

    admin_note: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    cancellation_reason: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    dispute_reason: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # =========================================================
    # TIMESTAMPS
    # =========================================================

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        nullable=False,
    )

    payment_confirmed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    assigned_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    cancelled_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
        nullable=False,
    )

    # =========================================================
    # RELATIONSHIPS
    # =========================================================

    listing = relationship(
        "Listing",
        back_populates="transactions",
    )

    # IMPORTANT :
    # User utilise buyer_transactions
    buyer = relationship(
        "User",
        foreign_keys=[buyer_id],
        back_populates="buyer_transactions",
    )

    # IMPORTANT :
    # User utilise seller_transactions
    seller = relationship(
        "User",
        foreign_keys=[seller_id],
        back_populates="seller_transactions",
    )

    assigned_admin = relationship(
        "User",
        foreign_keys=[assigned_admin_id],
    )

    messages = relationship(
        "Message",
        back_populates="transaction",
        cascade="all, delete-orphan",
        order_by="Message.created_at.asc()",
    )

    reports = relationship(
    "Report",
    foreign_keys="Report.transaction_id",
    back_populates="transaction",
    cascade="all, delete-orphan",
        
    )
    
    reviews = relationship(
    "Review",
    foreign_keys="Review.transaction_id",
    back_populates="transaction",
    cascade="all, delete-orphan",
        
    )
    
    platform_ledger_entries = relationship(
        "PlatformLedger",
        foreign_keys="PlatformLedger.transaction_id",
        back_populates="transaction",
    )

    # =========================================================
    # REPRESENTATION
    # =========================================================

    def __repr__(self) -> str:
        return (
            f"<Transaction "
            f"id={self.id} "
            f"reference={self.reference!r} "
            f"status={self.status!r}>"
        )
